#include <mpi.h>
#include <iostream>

int main(int argc, char** argv) {

    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // ---------------- MASTER ----------------
    if (rank == 0) {

        int tasks[6] = {10, 20, 30, 40, 50, 60};
        int ntasks = 6;
        int next_task = 0;
        int completed;
        MPI_Status status;

        // 1️⃣ Send one task to each worker initially
        for (int worker = 1; worker < size; worker++) {
            MPI_Send(&tasks[next_task], 1, MPI_INT,
                     worker, 0, MPI_COMM_WORLD);
            std::cout << "Master sent task "
                      << tasks[next_task]
                      << " to worker " << worker << std::endl;
            next_task++;
        }

        // 2️⃣ As workers finish, send new tasks
        while (next_task < ntasks) {

            MPI_Recv(&completed, 1, MPI_INT,
                     MPI_ANY_SOURCE, 0,
                     MPI_COMM_WORLD, &status);

            int worker = status.MPI_SOURCE;

            std::cout << "Master received completion from worker "
                      << worker << std::endl;

            MPI_Send(&tasks[next_task], 1, MPI_INT,
                     worker, 0, MPI_COMM_WORLD);

            std::cout << "Master sent task "
                      << tasks[next_task]
                      << " to worker " << worker << std::endl;

            next_task++;
        }

        // 3️⃣ Wait for remaining workers to finish
        for (int i = 1; i < size; i++) {
            MPI_Recv(&completed, 1, MPI_INT,
                     MPI_ANY_SOURCE, 0,
                     MPI_COMM_WORLD, &status);
        }

        // 4️⃣ Send stop signal
        int stop = -1;
        for (int worker = 1; worker < size; worker++) {
            MPI_Send(&stop, 1, MPI_INT,
                     worker, 0, MPI_COMM_WORLD);
        }

        std::cout << "Master sent stop signal to all workers"
                  << std::endl;
    }

    // ---------------- WORKERS ----------------
    else {

        while (true) {

            int task;

            MPI_Recv(&task, 1, MPI_INT,
                     0, 0, MPI_COMM_WORLD,
                     MPI_STATUS_IGNORE);

            if (task == -1) {
                std::cout << "Worker "
                          << rank << " stopping"
                          << std::endl;
                break;
            }

            std::cout << "Worker "
                      << rank
                      << " processing task "
                      << task << std::endl;

            // Send completion message back
            int done = 1;
            MPI_Send(&done, 1, MPI_INT,
                     0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Finalize();
    return 0;
}
